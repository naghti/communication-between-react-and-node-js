const express = require('express')
const config = require('config')
const authRouter = require('./routes/auth.routes')
const app = express()
const PORT = config.get('serverPort')
const corsMiddleware = require('./middleware/cors.middleware')

//решаю cors политику
app.use(corsMiddleware)
//роутинг чтобы можно было кинуть запрос
app.use("/api/auth", authRouter)

const start = async () => {
    try{
        app.listen(PORT, () =>{
            console.log('server started2')
        })
    }catch (e) {

    }
}

start()