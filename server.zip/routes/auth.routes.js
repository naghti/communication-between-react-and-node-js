const Router = require('express')

const router = new Router()

// принимаю пост запросы по путю registration
router.post('/registration', (req,res) => {
    try {
        res.status(200).json({message: 'all is good'})
    }catch (e) {
        res.send({message:'server error'})
    }
})

module.exports = router